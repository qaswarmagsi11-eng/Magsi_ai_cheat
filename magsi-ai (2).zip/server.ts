import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize GoogleGenAI client
const apiKey = process.env.GEMINI_API_KEY || '';
let aiClient: GoogleGenAI | null = null;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  aiClient = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health & status endpoint
app.get('/api/status', (_req, res) => {
  res.json({
    hasApiKey: Boolean(aiClient),
    appName: 'MAGSI AI',
    version: '1.0.0',
    model: 'gemini-3.8-flash',
  });
});

// Real-time Chat endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const {
      messages,
      systemInstruction,
      model = 'gemini-3.8-flash',
      imageBase64,
      imageMimeType = 'image/jpeg',
    } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required.' });
    }

    if (!aiClient) {
      // Graceful smart demo fallback if API key is not yet configured in Secrets
      const lastUserMsg = messages[messages.length - 1]?.text || 'Hello';
      const fallbackReply = generateFallbackResponse(lastUserMsg, systemInstruction);
      return res.json({ text: fallbackReply, isFallback: true });
    }

    // Prepare contents
    const contents: any[] = [];

    // History items
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      const isLatest = i === messages.length - 1;

      if (isLatest && imageBase64) {
        // Multimodal input with image attached
        const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
        contents.push({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: [
            {
              inlineData: {
                mimeType: imageMimeType,
                data: cleanBase64,
              },
            },
            {
              text: msg.text || 'Please examine this image and provide a thorough, helpful answer.',
            },
          ],
        });
      } else {
        contents.push({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: [{ text: msg.text || '' }],
        });
      }
    }

    const response = await aiClient.models.generateContent({
      model,
      contents,
      config: {
        systemInstruction:
          systemInstruction ||
          'You are an intelligent, friendly AI assistant in MAGSI AI (WhatsApp-style platform). Always reply in friendly, natural Roman Urdu by default (or the language the user speaks in, like English or Urdu). Keep responses helpful, culturally relatable, and authentic.',
        temperature: 0.7,
      },
    });

    const replyText = response.text || "I've processed your message.";
    return res.json({ text: replyText, isFallback: false });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    // Return informative error or graceful message
    const lastUserMsg = req.body?.messages?.[req.body.messages.length - 1]?.text || 'Hello';
    const fallback = generateFallbackResponse(lastUserMsg, req.body?.systemInstruction);
    return res.json({
      text: fallback,
      isFallback: true,
      errorNotice: error.message || 'Gemini service notice: Using local intelligent assistant.',
    });
  }
});

// Image Generation endpoint
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, style = 'Realistic', aspectRatio = '1:1' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required.' });
    }

    const enhancedPrompt = `${prompt}, styled as ${style}, ultra high quality, clean composition, 8k resolution aesthetics`;

    if (aiClient) {
      try {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [{ text: enhancedPrompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspectRatio as any,
            },
          },
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) {
            const imageUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
            return res.json({ imageUrl, prompt: enhancedPrompt, isFallback: false });
          }
        }
      } catch (genError: any) {
        console.warn('Image generation model notice, generating artistic vector fallback:', genError?.message);
      }
    }

    // Artistic SVG / DataURL placeholder if image gen model requires paid key or key unset
    const fallbackImage = generateStyledSvgImage(prompt, style, aspectRatio);
    return res.json({ imageUrl: fallbackImage, prompt: enhancedPrompt, isFallback: true });
  } catch (error: any) {
    console.error('Error in /api/generate-image:', error);
    const fallbackImage = generateStyledSvgImage(req.body?.prompt || 'MAGSI AI Art', 'Modern', '1:1');
    return res.json({ imageUrl: fallbackImage, prompt: req.body?.prompt, isFallback: true });
  }
});

// Text-to-Speech endpoint
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voice = 'Kore' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required.' });
    }

    if (aiClient) {
      try {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [{ text: text.slice(0, 300) }],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voice as any },
              },
            },
          },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          return res.json({
            audioBase64: base64Audio,
            mimeType: 'audio/wav',
          });
        }
      } catch (ttsErr: any) {
        console.warn('TTS API notice, using client Web Speech API fallback:', ttsErr?.message);
      }
    }

    return res.json({ audioBase64: null, useWebSpeech: true });
  } catch (err: any) {
    return res.json({ audioBase64: null, useWebSpeech: true });
  }
});

// Intelligent fallback generator for offline / initial demo mode in Roman Urdu
function generateFallbackResponse(query: string, instruction?: string): string {
  const lower = query.toLowerCase();

  if (lower.includes('doctor') || lower.includes('sehat') || lower.includes('dard') || lower.includes('health') || lower.includes('dawa') || lower.includes('tabiat')) {
    return `Salam! Main Doctor Faizan Magsi baat kar raha hoon. 🩺\n\nAap ki sehat hamari pehli tarjeeh hai. Aap ne jo alamat batayi hain:\n- **Tashkhees ka khulasa:** Aam tor par yeh thakawat, paani ki kami ya mamooli infection ki wajah se ho sakta hai.\n- **Mashwara:** Khoob paani piyein, mukammal aaram karein aur halki ghiza lein.\n- **Zaruri Hidayat:** Agar dard ya bukhar 24 ghante se zyada rahay, to qareebi clinic ja kar checkup lazmi karwayein. Khayal rakhein apna!`;
  }

  if (lower.includes('math') || lower.includes('+') || lower.includes('=') || lower.includes('solve') || lower.includes('hisab')) {
    return `### 📐 Math ka Step-by-Step Hal:\n\n1. **Sawaal Samajhein:** Aap ki equation ko step by step hal karte hain.\n2. **Formula:** Pehle basic operations aur brackets ko simplify karenge.\n3. **Calculation:** Step-by-step steps ko solve kiya gaya hai taake aap ko concepts samajh aa sakein.\n4. **Final Jawab:** verified jawab hazir hai.\n\n*Aap chahein to textbook ki photo khench kar bhi bhej sakte hain, main poora hal kar doonga!*`;
  }

  if (lower.includes('islam') || lower.includes('quran') || lower.includes('hadith') || lower.includes('namaz') || lower.includes('dua')) {
    return `Assalam-o-Alaikum wa Rahmatullah.\n\nDeen-e-Islam mein ilm hasil karna aur naik aamaal par mudawamat karna bohot afzal hai.\n\n- **Naseehat:** Hamesha sachai aur sabr ka daman thamein.\n- **Hawala:** Quran Majeed aur Sahih Hadith ki roshni mein yeh baat wazeh hai k mushkil k sath aasani hoti hai.\n\nAap ka koi makhsoos sawal hai to be-jhijhak poochein!`;
  }

  if (lower.includes('tasveer') || lower.includes('image') || lower.includes('photo') || lower.includes('picture')) {
    return `Zabardast! Main aap k liye aik shandar AI image generate kar raha hoon. Neeche diye gaye button se ya Studio se aap kisi bhi tarah ki photo bana sakte hain! ✨`;
  }

  if (lower.includes('sindhi') || lower.includes('magsi') || lower.includes('baloch') || lower.includes('culture')) {
    return `سلام ۽ آڌرڀاءُ! (Salam aur khush aamdeed!)\n\nMagsi qabeelay ki tareekh hamesha sharafat, ghairat, mehmaan-nawazi aur bahaduri se bhari hui hai. Chahe Sindh ho ya Balochistan, riwayat aur izzat hamari pehchan hai.\n\nAap mardana tareekh ya shairi k bare mein kya janna chahte hain?`;
  }

  if (lower.includes('laba') || lower.includes('dost') || lower.includes('friend') || lower.includes('hal') || lower.includes('kese ho')) {
    return `Aray salam! Main theek thaak hoon, aap sunao kaisay ho? Aaj kya exciting plan hai? Koi gup shup karni ho ya koi kaam, main hamesha hazir hoon! 😊`;
  }

  return `Salam! Main MAGSI AI ka smart assistant hoon. 🤖\n\nAap mujh se Roman Urdu ya English mein jo chahein pooch sakte hain: parhai, sehat, shairi, tasveer banana ya aam guftagu! Boliye, main kis tarah madad karoon?`;
}

// Generates an attractive stylized SVG data URL when image gen is in demo/fallback mode
function generateStyledSvgImage(prompt: string, style: string, aspectRatio: string): string {
  let width = 800;
  let height = 800;
  if (aspectRatio === '16:9') {
    width = 1280;
    height = 720;
  } else if (aspectRatio === '9:16') {
    width = 720;
    height = 1280;
  } else if (aspectRatio === '4:3') {
    width = 800;
    height = 600;
  }

  const cleanPrompt = prompt.replace(/[<>&"]/g, ' ').slice(0, 70);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#00A884"/>
        <stop offset="50%" stop-color="#0E3A2F"/>
        <stop offset="100%" stop-color="#0B141A"/>
      </linearGradient>
      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="1"/>
      </pattern>
      <filter id="glow">
        <feGaussianBlur stdDeviation="6" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="${width}" height="${height}" fill="url(#g)"/>
    <rect width="${width}" height="${height}" fill="url(#grid)"/>
    <circle cx="${width / 2}" cy="${height / 2 - 30}" r="${Math.min(width, height) * 0.28}" fill="none" stroke="#25D366" stroke-width="3" stroke-dasharray="8 6" opacity="0.6"/>
    <circle cx="${width / 2}" cy="${height / 2 - 30}" r="${Math.min(width, height) * 0.16}" fill="rgba(0,168,132,0.2)" stroke="#25D366" stroke-width="2"/>
    <text x="${width / 2}" y="${height / 2 - 20}" font-family="system-ui, -apple-system, sans-serif" font-size="28" font-weight="bold" fill="#FFFFFF" text-anchor="middle" filter="url(#glow)">MAGSI STUDIO</text>
    <text x="${width / 2}" y="${height / 2 + 16}" font-family="system-ui, -apple-system, sans-serif" font-size="16" fill="#25D366" text-anchor="middle" letter-spacing="3">${style.toUpperCase()} • ${aspectRatio}</text>
    <rect x="${width * 0.1}" y="${height - 90}" width="${width * 0.8}" height="56" rx="16" fill="rgba(11,20,26,0.85)" stroke="rgba(0,168,132,0.4)" stroke-width="1.5"/>
    <text x="${width / 2}" y="${height - 56}" font-family="system-ui, -apple-system, sans-serif" font-size="15" fill="#E9EDEF" text-anchor="middle">"${cleanPrompt}..."</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Mounting Vite in development or serving dist in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MAGSI AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
