import React from 'react';
import * as Icons from 'lucide-react';

interface IconProps {
  name: string;
  className?: string;
  size?: number;
}

export const IconResolver: React.FC<IconProps> = ({ name, className = 'w-5 h-5', size }) => {
  const LucideIcon = (Icons as any)[name] || Icons.Sparkles;
  return <LucideIcon className={className} size={size} />;
};

// Recreates the exact WhatsApp-style "cm magsi cheat" app icon uploaded by user in width_447.webp
export const MagsiLogo: React.FC<{ size?: number; className?: string }> = ({
  size = 44,
  className = '',
}) => {
  return (
    <div
      className={`relative select-none flex items-center justify-center rounded-[22%] bg-gradient-to-b from-[#25D366] to-[#128C7E] shadow-md shadow-emerald-950/40 overflow-hidden shrink-0 ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full p-1"
      >
        <circle cx="100" cy="98" r="74" fill="rgba(0,0,0,0.06)" />
        {/* White Speech Bubble Outline */}
        <path
          d="M100 24C58.026 24 24 57.578 24 99C24 113.88 28.32 127.76 35.8 139.52L26 174L61.76 164.54C73.18 170.58 86.2 174 100 174C141.974 174 176 140.422 176 99C176 57.578 141.974 24 100 24Z"
          stroke="white"
          strokeWidth="11"
          strokeLinejoin="round"
          fill="none"
        />
        {/* 'cm' bold letters */}
        <text
          x="100"
          y="108"
          textAnchor="middle"
          fill="white"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="68"
          letterSpacing="-4"
        >
          cm
        </text>
        {/* 'magsi cheat' text */}
        <text
          x="100"
          y="138"
          textAnchor="middle"
          fill="white"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="800"
          fontSize="17"
          letterSpacing="-0.5"
        >
          magsi cheat
        </text>
      </svg>
    </div>
  );
};
